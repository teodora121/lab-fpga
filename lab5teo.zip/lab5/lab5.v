module lab5 ( 
 input  wire clk, 
 input  wire S1, S2, 
 output wire X, Y,
 output reg  buzzer = 1'b1 
  );
  reg [7:0] x = 80, y = 60; 
  reg [9:0] sx = 0, sy = 0; 
  reg [10:0] timer = 0;
  reg [2:0] phase = 0;       
  reg [3:0] segment = 0; 
  reg [6:0] t = 0; 
   // Button synchronization 016 
	reg s1a = 1, s1b = 1; 
   reg s2a = 1, s2b = 1; 
	 // Debounce 020  
	 reg [18:0] db1 = 0, db2 = 0; 
	 reg k1 = 1, k2 = 1; 
	 reg prev1 = 1, prev2 = 1; 
	  // Beep: 2 kHz for 80 ms
	  reg [13:0] tone_count = 0;
  reg [21:0] beep_count = 0;
// Coordinates: {x0, y0, x1, y1}
function [31:0] shape; 
 input [2:0] p;         
 input [3:0] s;
 begin
 shape = {8'd80,8'd60,8'd80,8'd60};
 case (p)

        // ===== Faza 0: T E O =====
        0: case(s)
          // T (x 35..90)
          0: shape={8'd35, 8'd60, 8'd90, 8'd60};
          1: shape={8'd90, 8'd60, 8'd62, 8'd60};
          2: shape={8'd62, 8'd60, 8'd62, 8'd210};
          // E (x 102..157)
          3: shape={8'd157,8'd60, 8'd102,8'd60};
          4: shape={8'd102,8'd60, 8'd102,8'd210};
          5: shape={8'd102,8'd210,8'd157,8'd210};
          6: shape={8'd102,8'd135,8'd147,8'd135};
          // O (x 169..224)
          7: shape={8'd169,8'd60, 8'd224,8'd60};
          8: shape={8'd224,8'd60, 8'd224,8'd210};
          9: shape={8'd224,8'd210,8'd169,8'd210};
          10: shape={8'd169,8'd210,8'd169,8'd60};
        endcase

        // ===== Faza 1: E L I =====
        1: case(s)
          // E (x 35..90)
          0: shape={8'd90, 8'd60, 8'd35, 8'd60};
          1: shape={8'd35, 8'd60, 8'd35, 8'd210};
          2: shape={8'd35, 8'd210,8'd90, 8'd210};
          3: shape={8'd35, 8'd135,8'd80, 8'd135};
          // L (x 102..157)
          4: shape={8'd102,8'd60, 8'd102,8'd210};
          5: shape={8'd102,8'd210,8'd157,8'd210};
          // I (x 169..224)
          6: shape={8'd169,8'd60, 8'd224,8'd60};
          7: shape={8'd224,8'd60, 8'd196,8'd60};
          8: shape={8'd196,8'd60, 8'd196,8'd210};
          9: shape={8'd196,8'd210,8'd169,8'd210};
          10: shape={8'd169,8'd210,8'd224,8'd210};
        endcase

        // ===== Faza 2: Steaua =====
        2: case(s)
          0: shape={8'd128,8'd55, 8'd167,8'd190};
          1: shape={8'd167,8'd190,8'd66, 8'd105};
          2: shape={8'd66, 8'd105,8'd190,8'd105};
          3: shape={8'd190,8'd105,8'd89, 8'd190};
          4: shape={8'd89, 8'd190,8'd128,8'd55};
        endcase
      endcase
 end
 endfunction
  reg [3:0] last_segment;
 always @(*) begin  
 case (phase) 
 0: last_segment = 10;  // T E O
 1: last_segment = 10;  // E L I
 2: last_segment = 4;   // Stea
 default: last_segment = 0;
 endcase
  end
 wire [31:0] v = shape(phase, segment);

 // Inversare verticala pentru nume (faza 0 si 1); steaua ramane la fel
 wire        flip = (phase != 2);
 wire [8:0]  y0f  = 9'd270 - {1'b0, v[23:16]};
 wire [8:0]  y1f  = 9'd270 - {1'b0, v[7:0]};

 wire [7:0] x0 = v[31:24];
 wire [7:0] y0 = flip ? y0f[7:0] : v[23:16];
 wire [7:0] x1 = v[15:8];
 wire [7:0] y1 = flip ? y1f[7:0] : v[7:0];

  wire signed [10:0] dx =   
 $signed({1'b0,x1}) - $signed({1'b0,x0});
 wire signed [10:0] dy = 
 $signed({1'b0,y1}) - $signed({1'b0,y0});
 wire signed [20:0] ix =
 $signed({1'b0,x0}) +     
 (dx * $signed({1'b0,t})) / 63;
 wire signed [20:0] iy =
 $signed({1'b0,y0}) +
 (dy * $signed({1'b0,t})) / 63;
 wire press1 = prev1 && !k1;
 wire press2 = prev2 && !k2;
 always @(posedge clk) begin    
 // Synchronize buttons 
 s1a <= S1;
 s1b <= s1a;
 s2a <= S2;
 s2b <= s2a;
 // Debounce: approximately 10 ms
 if (s1b == k1)
 db1 <= 0;
 else if (db1 == 499999) begin
 db1 <= 0;
 k1 <= s1b;
 end else
 db1 <= db1 + 1'b1;
 if (s2b == k2)
 db2 <= 0;
 else if (db2 == 499999) begin
 db2 <= 0;
 k2 <= s2b;
 end else
 db2 <= db2 + 1'b1;
 prev1 <= k1;
 prev2 <= k2;
 // Working sigma-delta DAC
 sx <= {2'b00,sx[7:0]} + {2'b00,x};
 sy <= {2'b00,sy[7:0]} + {2'b00,y};
 // Button selection
 if (press1 || press2) begin
 if (press1)
phase <= (phase == 2) ? 0 : phase + 1'b1;
 else
phase <= (phase == 0) ? 2 : phase - 1'b1;
 segment <= 0;
 t <= 0;
 timer <= 0;
 // Start beep
 beep_count <= 4000000;
 tone_count <= 0;
 buzzer <= 1'b1;
 end else begin
 // Drawing engine
 if (timer == 1388) begin
timer <= 0;
x <= ix[7:0];
y <= iy[7:0];
if (t == 63) begin
t <= 0;
segment <= (segment == last_segment) ?
0 : segment + 1'b1;
end else
t <= t + 1'b1;
 end else
timer <= timer + 1'b1;
 // Buzzer oscillator
 if (beep_count != 0) begin
beep_count <= beep_count - 1'b1;
if (tone_count == 12499) begin
tone_count <= 0;
buzzer <= ~buzzer;
end else
tone_count <= tone_count + 1'b1;
 end else begin
 // Inactive buzzer = HIGH
buzzer <= 1'b1;
tone_count <= 0;
 end
 end
 end
  assign X = sx[8];
  assign Y = sy[8];
endmodule