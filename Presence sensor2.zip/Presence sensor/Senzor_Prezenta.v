
module Senzor_Prezenta (
    input wire clk,
    inout wire sensor,
    output wire buzzer,
    output reg [7:0] seg,
    output reg [3:0] dig
);



    localparam CHARGE  = 2'd0;
    localparam MEASURE = 2'd1;
    localparam REST    = 2'd2;

   localparam [17:0] SENSITIVITY = 18'd15;

    reg [1:0] state = CHARGE;
    reg [17:0] ticks = 0;

    assign sensor = (state == CHARGE) ? 1'b1 : 1'bz;

    reg s0 = 0, s1 = 0;

    always @(posedge clk) begin
        s0 <= sensor;
        s1 <= s0;
    end

    reg [21:0] sum16 = 0;
    reg [3:0] samples = 0;

    reg [17:0] avg = 0;
    reg [17:0] baseline = 0;

    reg calibrated = 0;
    reg presence = 0;

    wire [21:0] total16 =
        sum16 + {4'b0000, ticks};

    wire [17:0] next_avg = total16 >> 4;

    wire [17:0] next_delta =
        (next_avg > baseline) ?
        (next_avg - baseline) : 18'd0;

    always @(posedge clk) begin
        case (state)

            CHARGE: begin
                if (ticks >= 18'd4999) begin
                    ticks <= 0;
                    state <= MEASURE;
                end
                else
                    ticks <= ticks + 1'b1;
            end

            MEASURE: begin
                if ((ticks >= 18'd8 && !s1) ||
                     ticks >= 18'd99999) begin

                    if (!s1 &&
                        ticks >= 18'd8 &&
                        ticks < 18'd99999) begin

                        if (samples == 4'd15) begin
                            avg <= next_avg;

                            if (!calibrated) begin
                                baseline <= next_avg;
                                calibrated <= 1'b1;
                                presence <= 1'b0;
                            end
                            else begin
                                if (next_delta >= SENSITIVITY)
                                    presence <= 1'b1;
                                else
                                    presence <= 1'b0;
                            end

                            samples <= 0;
                            sum16 <= 0;
                        end
                        else begin
                            samples <= samples + 1'b1;
                            sum16 <= total16;
                        end

                    end
                    else begin
                        presence <= 1'b0;
                        calibrated <= 1'b0;
                        samples <= 0;
                        sum16 <= 0;
                    end

                    ticks <= 0;
                    state <= REST;
                end
                else
                    ticks <= ticks + 1'b1;
            end

            REST: begin
                if (ticks >= 18'd49999) begin
                    ticks <= 0;
                    state <= CHARGE;
                end
                else
                    ticks <= ticks + 1'b1;
            end

            default: begin
                state <= CHARGE;
                ticks <= 0;
            end
        endcase
    end



    wire [17:0] delta =
        (avg > baseline) ?
        (avg - baseline) : 18'd0;

    reg [16:0] half_period;
    reg [15:0] frequency;

    always @(*) begin
        if (delta >= 30) begin
            half_period = 17'd6250;
            frequency = 16'd4000;
        end
        else if (delta >= 18) begin
            half_period = 17'd8333;
            frequency = 16'd3000;
        end
        else if (delta >= 10) begin
            half_period = 17'd10000;
            frequency = 16'd2500;
        end
        else if (delta >= 6) begin
            half_period = 17'd12500;
            frequency = 16'd2000;
        end
        else begin
            half_period = 17'd25000;
            frequency = 16'd1000;
        end
    end

    reg [16:0] audio_counter = 0;
    reg audio_wave = 0;

    always @(posedge clk) begin
        if (audio_counter >= half_period - 1'b1) begin
            audio_counter <= 0;
            audio_wave <= ~audio_wave;
        end
        else
            audio_counter <= audio_counter + 1'b1;
    end

    assign buzzer =
        (calibrated && presence) ? ~audio_wave : 1'b1;

   

    wire [15:0] display_frequency =
        (calibrated && presence) ? frequency : 16'd0;

    reg [3:0] thousands;
    reg [3:0] hundreds;
    reg [3:0] tens;
    reg [3:0] units;

    always @(*) begin
        thousands = 0;
        hundreds = 0;
        tens = 0;
        units = 0;

        case (display_frequency)
            16'd1000: begin
                thousands = 1;
            end

            16'd2000: begin
                thousands = 2;
            end

            16'd2500: begin
                thousands = 2;
                hundreds = 5;
            end

            16'd3000: begin
                thousands = 3;
            end

            16'd4000: begin
                thousands = 4;
            end

            default: begin
                thousands = 0;
            end
        endcase
    end



    // 50 MHz clock
    // Schimbam cifra la fiecare 1 ms

    reg [15:0] refresh_counter = 0;
    reg [1:0] digit_select = 0;

    always @(posedge clk) begin
        if (refresh_counter == 16'd49999) begin
            refresh_counter <= 0;
            digit_select <= digit_select + 1'b1;
        end
        else
            refresh_counter <= refresh_counter + 1'b1;
    end

    reg [3:0] current_digit;

    always @(*) begin
        case (digit_select)
            2'd0: begin
                dig = 4'b1110;
                current_digit = units;
            end

            2'd1: begin
                dig = 4'b1101;
                current_digit = tens;
            end

            2'd2: begin
                dig = 4'b1011;
                current_digit = hundreds;
            end

            2'd3: begin
                dig = 4'b0111;
                current_digit = thousands;
            end

            default: begin
                dig = 4'b1111;
                current_digit = 0;
            end
        endcase
    end

    

    // Segmente active LOW
    // Ordine: abcdefg + dp

    always @(*) begin
        case (current_digit)
            4'd0: seg = 8'hC0;
            4'd1: seg = 8'hF9;
            4'd2: seg = 8'hA4;
            4'd3: seg = 8'hB0;
            4'd4: seg = 8'h99;
            4'd5: seg = 8'h92;
            4'd6: seg = 8'h82;
            4'd7: seg = 8'hF8;
            4'd8: seg = 8'h80;
            4'd9: seg = 8'h90;
            default: seg = 8'hFF;
        endcase
    end

endmodule
